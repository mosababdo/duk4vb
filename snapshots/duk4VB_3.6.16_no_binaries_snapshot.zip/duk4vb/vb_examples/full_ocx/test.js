
//v = fso.FileExists("c:\\autoexec.bat")
//print(v)
//alert(window.location)

alert(1/0)