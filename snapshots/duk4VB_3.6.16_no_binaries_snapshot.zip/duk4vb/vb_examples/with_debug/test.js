
a = 1
a++;
alert(a)
/* while(a){ //test break
a++;
}*/
 
var gs = "string1"
print(1)
var ga = b(0)
ga = add_two(ga) //in a library file lib.js you can not step into it...

function b(c){ c++; return c+=1; }

function main(){
	var a = 1
    var v1 = parseInt(0);
	v1 = b(v1)
	v1 = b(v1)
	var c = false
	var d = null
	var e = [1,2,3,4]
    var s = "this is my string!"
	return v1;
}

main()
print(1)
