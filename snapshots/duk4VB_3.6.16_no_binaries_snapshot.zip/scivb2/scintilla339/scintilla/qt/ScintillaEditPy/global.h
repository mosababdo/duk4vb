#include "pyside_global.h"

#include "ScintillaEditBase.h"
#include "ScintillaEdit.h"
