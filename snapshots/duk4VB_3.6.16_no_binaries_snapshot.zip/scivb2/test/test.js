
function a(x){
	return a++;
}

b =1;
b = a(b);
b++
alert(b)
	