
see readme file in COM subdirectory